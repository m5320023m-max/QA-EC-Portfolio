const { Builder, By } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");
const assert = require("assert");
const fs = require("fs");
const path = require("path");



function createRunFolder() {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    const hour = String(now.getHours()).padStart(2, "0");
    const minute = String(now.getMinutes()).padStart(2, "0");
    const second = String(now.getSeconds()).padStart(2, "0");

    const folderName =
        `${year}${month}${day}_${hour}${minute}${second}`;

    const folderPath =
        path.join(__dirname, "screenshots", folderName);

    fs.mkdirSync(folderPath, { recursive: true });

    return folderPath;
}

const runFolder = createRunFolder()

async function saveScreenshot(driver, testCaseId) {
    const image = await driver.takeScreenshot();

    const filePath = path.join(
        runFolder,
        `${testCaseId}.png`
    );

    fs.writeFileSync(
        filePath,
        image,
        "base64"
    );
}

async function runTest() {
    const options = new chrome.Options();

    options.addArguments("--log-level=3");
    options.excludeSwitches("enable-logging");

    const driver = await new Builder()
        .forBrowser("chrome")
        .setChromeOptions(options)
        .build();

    try {
        await driver.get("http://127.0.0.1:5500/index.html");

        console.log("TC-01 想定している商品一覧画面へ到達できているか確認");
        const title = await driver.findElement(By.css("h1")).getText();
        console.log(title);
        assert.strictEqual(title, "商品一覧");
        await saveScreenshot(driver, "TC-01");
        console.log("結果：PASS");
        console.log("--------------------");

        await driver.sleep(2000);
        console.log("TC-02 テスト用商品が登録されているかどうかの確認");
        const productName = await driver.findElement(By.id("product-name")).getText();
        const productPrice = await driver.findElement(By.id("product-price")).getText();
        console.log(productName);
        console.log(productPrice);
        assert.strictEqual(productName, "テスト商品A");
        assert.strictEqual(productPrice, "1000円");
        await saveScreenshot(driver, "TC-02");
        console.log("結果：PASS");
        console.log("--------------------");

        await driver.sleep(2000);
        await driver.findElement(By.id("product-detail-link")).click();
        console.log("TC-03 一覧と詳細の情報が一致しているかどうか");
        const detailProductName = await driver.findElement(By.id("product-name")).getText();
        const detailProductPrice = await driver.findElement(By.id("product-price")).getText();
        console.log(detailProductName);
        console.log(detailProductPrice);
        assert.strictEqual(detailProductName, productName);
        assert.strictEqual(detailProductPrice, productPrice);
        await saveScreenshot(driver, "TC-03");
        console.log("結果：PASS");
        console.log("--------------------");

        await driver.sleep(2000);
        console.log("TC-04 数量を指定してカートへ追加し、カート数量が反映される");
        const quantityInput = await driver.findElement(By.id("quantity"));
        await quantityInput.clear();
        await quantityInput.sendKeys("3");
        await driver.findElement(By.id("add-cart")).click();
        const cartCount = await driver.findElement(By.id("cart-count")).getText();
        assert.strictEqual(cartCount, "3");
        await saveScreenshot(driver, "TC-04");
        console.log("結果：PASS");
        console.log("--------------------");

        await driver.sleep(2000);
        console.log("TC-05 カートに選択した商品が表示されている");
        await driver.findElement(By.id("cart-link")).click();
        const cartProductName = await driver
            .findElement(By.id("cart-product-name"))
            .getText();
        assert.strictEqual(cartProductName, detailProductName);
        await saveScreenshot(driver, "TC-05");
        console.log("結果：PASS");
        console.log("--------------------");

        await driver.sleep(2000);
        console.log("TC-06 選択した商品の数量・金額が期待値と一致する");
        const cartQuantity = await driver
            .findElement(By.id("cart-quantity"))
            .getText();

        const cartPrice = await driver
            .findElement(By.id("cart-price"))
            .getText();

        const cartTotal = await driver
            .findElement(By.id("cart-total"))
            .getText();

        console.log("カート数量：" + cartQuantity);
        console.log("カート単価：" + cartPrice);
        console.log("カート合計：" + cartTotal);
        assert.strictEqual(cartQuantity, "3");
        assert.strictEqual(cartPrice, productPrice.replace("円", ""));

        const expectedTotal =
            Number(productPrice.replace("円", "")) * Number(cartQuantity);

        assert.strictEqual(
            Number(cartTotal),
            expectedTotal
        );

        await saveScreenshot(driver, "TC-06");
        console.log("結果：PASS");
        console.log("--------------------");


        await driver.sleep(5000);

    }catch{
        console.log("エラー発生");
        console.log("-----------------");
    } finally {
        await driver.quit();
    }
}

runTest();